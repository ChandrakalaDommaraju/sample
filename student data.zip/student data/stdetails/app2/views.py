#from django.shortcuts import render
#from django.shortcuts import HttpResponse
from .models import student,Allsubjects,StudentMarks
#from rest_framework.views import APIView
#from django.views.decorators.csrf import csrf_exempt
#from django.views.decorators.csrf import csrf_exempt,csrf_protect
#import numpy as np
# Create your views here.
from django.http import JsonResponse
from rest_framework.response import Response
from rest_framework.views import APIView
from django.db.models import Q
from rest_framework import serializers
from rest_framework import status
import json
import pandas as pd
from django.db.models import Count
from rest_framework.response import Response
#from django.db.models.lookups import GreaterThan, LessThan
from django.http import HttpResponse
def helloWorld(request):
    return HttpResponse("Hello World")


class student_list(APIView):
    def get(self, request):
        #articles = student.objects.create(Name="jyo",Rollnumber=123,Dateofbirth=21-4-3)
        students = student.objects.all().values()
        c=student.objects.filter(id=request.data["id"])
        print(c)
        #return HttpResponse(student.objects.get(pk=1))
        print(students)
        return HttpResponse("updted")
        #return HttpResponse(list(c))

    def post(self,request):
        try:
            p=student(Name=request.data["name"],Rollnumber=request.data["rollnumber"],Dateofbirth=request.data["dateofbirth"])
            std=p.save()
            print(std)
            return HttpResponse("post method updated")

        except Exception as e:
            return HttpResponse(e)
            #return HttpResponse({"data":e,"message":"failed","satus_code":500})
class studentmarks(APIView):
    def post(self,request):
        try:
            studenttable=student.objects.get(Rollnumber=request.data["rollnumber"])
            subjecttable=Allsubjects.objects.get(subject_name=request.data["subjectname"])
            p1 =StudentMarks(marks_value=request.data["marks_value"], student_id=studenttable.id, subject_id=subjecttable.id)
            p1.save()
            print(p1)
            #print(StudentMarks.objects.all().values())
            #print(request.data)
           # print(request.GET['name'])
            return HttpResponse("updated")
        except Exception as e:
            return HttpResponse(e)

class particularstudent(APIView):
    def get(self,request):
        #print(request)
        try:
            b={}
            d=[]
            #print(request)
            ps=StudentMarks.objects.filter(student_id=request.GET["student_id"])
            print(ps)
            #ps = StudentMarks.objects.filter(id=request.data["id"]).select_related('student')
            # ps=StudentMarks.objects.filter(id=190).values()
            for i in ps:
                b["Name"]=i.student.Name
                b[i.subject.subject_name] = i.marks_value
            d.append(b)
            # print('f',ps.student.Name)
            #return HttpResponse(d)
            return HttpResponse(d, status=status.HTTP_200_OK)
        except Exception as e:
            print(e)
            return HttpResponse(e)

class allmarks(APIView):
    """to get particular student mark by passing student id"""
    def get(self,request):
        try:
            d = []
            # print(request)
            students = student.objects.all()
            for s in students:
                b= {}
                b['name'] = s.Name
                ps = StudentMarks.objects.filter(student_id=s.id)
                print(ps)
                #print(students.count(ps))
                for i in ps:
                    b[i.subject.subject_name] = i.marks_value
                d.append(b)
            print(ps)
            # ps = StudentMarks.objects.filter(id=request.data["id"]).select_related('student')
            # ps=StudentMarks.objects.filter(id=190).values()
            #return HttpResponse(d)
            return JsonResponse({"models_to_return": d}, status=status.HTTP_200_OK, safe=False)
        except Exception as e:
            return HttpResponse(e)
class maxmarks(APIView):
    def get(self, request):
        try:
        #b = {}
            d = []
            ps=StudentMarks.objects.filter(subject_id=1,marks_value__gte=70)
            print(len(ps))
            for i in ps:
                d.append(i.student.Name)
            return JsonResponse({"count": len(ps),"Student_name":d}, status=status.HTTP_200_OK, safe=False)
        except Exception as e:
            return HttpResponse(e)

class totalmarks(APIView):
    def get(self,request):
        try:
            marks=[]
            name_of_student = []
            d = {}
            new = []
            b = StudentMarks.objects.filter(student_id=request.GET["student_id"]).select_related("student")
            for i in b:
                name_of_student.append(i.student.Name)
                marks.append(i.marks_value)
                #print(marks)
            Total_marks = sum(marks)
            name_1 = name_of_student[0]
            d['student_name'] = name_1
            d['marks'] = marks
            d['Total_marks'] = Total_marks
            new.append(d)
            return JsonResponse(new, status=status.HTTP_200_OK, safe=False)
        except Exception as e:
            return HttpResponse(e)
class Grades(APIView):
    def get(self,request):
        try:
            d = []
            k=[]
            students = student.objects.all()
            for s in students:
                # print(s.id)
                b = {}
                b['name'] = s.Name
                ps = StudentMarks.objects.filter(student_id=s.id)
                #print(ps)
                marks = []
                for i in ps:
                    b[i.subject.subject_name] = i.marks_value
                    marks.append(i.marks_value)
                print('m',marks)
                    #total = sum(marks)
                total1 = 0
                for ele in range(0, len(marks)):
                    total1 = total1 + marks[ele]
                print("new total", total1)
                b['total'] = total1
                avger = 0
                count = len(marks)
                grade_value ="F grade"
                if count != 0:
                    avger = round(total1/count)
                    print('avger',avger)
                    k.append(avger)
                if avger > 90:
                    grade_value = "A grade"
                elif avger > 80 and avger < 90:
                    grade_value = "B grade"
                elif avger > 70 and avger < 80:
                    grade_value = "C grade"
                elif avger > 60 and avger < 70:
                    grade_value = "D grade"
                elif avger > 55 and avger < 60:
                    grade_value = "E grade"
                else:
                    grade_value = "F grade"

                b['grade'] = grade_value
                print(grade_value,"kkk")
                d.append(b)
                #pandas.read_json("input.json").to_excel("output.xlsx")
                #df=pd.read_json("http://127.0.0.1:8000/app2/result/").to_excel("output.xlsx")
                #print(df)
                a=json.dumps(d)
                df=pd.DataFrame([[2,3,4,5], [12, 22, 32,5], [3,32, 33,6],[2,3,4,7]],index=['srisai','sai','om','sai'], columns=['name', 'English', 'maths','telugu'])
                #df= pd.read_json(a).to_excel("output.xlsx")
                print(df)
                #print(a)
            return JsonResponse({'name': d}, status=status.HTTP_200_OK, safe=False)
        except Exception as e:
            return HttpResponse(e)

"""class result(APIView):
    def get(self,request):
        try:
            count1=student.objects.all().count()
            print(count1)
            return HttpResponse("students counted succesfully")
        except Exception as e:
           return HttpResponse(e)"""

"""class stdetails1(APIView):
    def post(self,request):
        #p1 = student(Name=request.data["name"], Rollnumber=request.data["rollnumber"],Dateofbirth=request.data["dateofbirth"])
        #data1=p1.save()
        s=student.objects.filter(Name=request.data["name"])
        print(student.objects.filter(Name=request.data["name"]))
        print(len(s))
        if len(s)>0:
            print("already exists")
            return HttpResponse("already exists")
        else:
            p1 = StudentMarks(name=request.data["name"],rollnumber=request.data["rollnumber"],dateofbirth =request.data["dateofbirth"])
            p1.save()
            return HttpResponse(p1)
"""

