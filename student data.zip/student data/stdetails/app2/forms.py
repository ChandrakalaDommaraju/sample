from django import forms
from .models import student,Allsubjects,StudentMarks

class student(forms.ModelForm):
    class Meta:
        model = student
        fields ='__all__'

class Allsubject(forms.ModelForm):
    class Meta:
        model=Allsubjects
        fields='__all__'
class StudentMarks(forms.ModelForm):
    class Meta:
        model=StudentMarks
        fields='__all__'