from django.db import models
#from datetime import datetime

"""def student(request):
    Name = models.CharField(max_length=200)
    Rollnumber = models.CharField(max_length=100)
    Dateofbirth = models.DateField()"""

class student(models.Model):
    Name=models.CharField(max_length=200)
    Rollnumber=models.CharField(max_length=100)
    Dateofbirth=models.DateField()

    def __str__(self):
        return self.Name
class Allsubjects(models.Model):
    subject_name= models.CharField(max_length=50)

    def __str__(self):
        return self.subject_name

class StudentMarks(models.Model):
    marks_value = models.IntegerField()
    student = models.ForeignKey(student, on_delete=models.CASCADE)
    subject = models.ForeignKey(Allsubjects, on_delete=models.CASCADE)
    def __str__(self):
        return str(self.marks_value)
"""class dummydata(models.Model):
    fullname = models.CharField(max_length=200)
    mobile_number = models.IntegerField()
    age=models.IntegerField()

    def __str__(self):
        return self.fullname

from django.db import models

class Author(models.Model):
  name = models.CharField(max_length=255)
  email = models.EmailField()

class Article(models.Model):
    title = models.CharField(max_length=120)
    description = models.TextField()
    body = models.TextField()
    author = models.ForeignKey('Author', related_name='app2')"""

