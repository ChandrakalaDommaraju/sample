
from django.urls import path

from . import views
from django.conf.urls import url

#Urls for app Utils is been given below

urlpatterns = [
    #path('memo/',views.marksmemo.as_view()),
    #path('marks/',views.studentmarks.as_view()),
    url('marks/',views.studentmarks.as_view()),
    url('psd/',views.particularstudent.as_view()),
    url('allmark/',views.allmarks.as_view()),
    #url("results/",views.result.as_view()),
    #url("grades/",views.grade.as_view()),
    #url("allsub/",views.subjects.as_view()),
    url("student/",views.student_list.as_view()),
    url("max/",views.maxmarks.as_view()),
    #url("data1/",views.stdetails1.as_view()),
    url("total/",views.totalmarks.as_view()),
    url("result/",views.Grades.as_view()),
]